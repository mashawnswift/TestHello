//: Playground - noun: a place where people can play

import Foundation
/*
var reversedString = ""
for char in "ABCDEFG".characters {
    reversedString = String(char) + reversedString
}
print(reversedString)
var varInt:Int?
print(varInt?.description)
varInt = 10
if var newVal = varInt{
    newVal += 1
    print("newVal = \(newVal)")
}
let BIndex = reversedString.characters.index(of: "B")
let IndexString = String(reversedString.characters.prefix(upTo:BIndex!))
print(IndexString)
var varfloat: Float = 2.048e3
print(varfloat)

var tmpInt: Int8 = 20
tmpInt.customMirror*/
/*var sortingInline = [2,4,7,8,102,55,44,33]
var sorting = sortingInline.sorted()
sorting = sortingInline.sorted(by:{$0 > $1})
sorting = sortingInline.sorted(by: {$1 > $0})
sorting = sortingInline.sorted(by: {$1 > $0})
print(sortingInline)
print(sorting)*/
//sortingInline.sort()
//sorting = sortingInline.sort({$0 >$1})

let names = ["Lily","Anna","Poly","Gray"]
func compareName(s1:String, s2:String)->Bool{
    return s1 < s2
}
var sortedArray = names.sorted(by: {$0 > $1})

var arrayValue = "array Value:"
for index in sortedArray{
    arrayValue += (index+",")
}
print(arrayValue)

